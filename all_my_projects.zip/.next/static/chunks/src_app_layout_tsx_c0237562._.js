(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/node_modules_framer-motion_dist_es_92139a2a._.js",
  "static/chunks/node_modules_b5614c29._.js",
  "static/chunks/src_3a13c8f5._.js"
],
    source: "dynamic"
});
