"use client"

import Image from 'next/image';
import { motion, useScroll, useTransform } from 'framer-motion';
import { SectionWrapper } from './section-wrapper';
import { SectionHeader } from './section-header';
import { Card, CardContent } from './ui/card';
import { useRef } from 'react';

const motionProps = {
  initial: { opacity: 0, y: 50, scale: 0.9 },
  whileInView: { opacity: 1, y: 0, scale: 1 },
  viewport: { once: true },
  transition: { duration: 0.8, type: 'spring', stiffness: 100 },
};

export function About() {
  const targetRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start end", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ['-10%', '10%']);
  const imageY = useTransform(scrollYProgress, [0, 1], ['-20%', '20%']);
  const textY = useTransform(scrollYProgress, [0, 1], ['10%', '-10%']);

  return (
    <SectionWrapper ref={targetRef} id="about" className="bg-secondary" style={{ perspective: '2000px' }}>
      <SectionHeader 
        title="About Me"
        description="A little bit about my journey and passions."
      />
      <motion.div style={{ y }} className="mx-auto max-w-5xl">
        <motion.div {...motionProps}>
          <Card className="overflow-hidden transform-style-3d">
            <CardContent className="p-0 md:p-6 lg:p-8">
              <div className="grid grid-cols-1 items-center gap-8 md:grid-cols-3">
                <motion.div 
                  style={{ y: imageY }}
                  className="md:col-span-1"
                  whileHover={{ scale: 1.05, rotateY: 10, z: 10 }}
                  transition={{ type: 'spring', stiffness: 200 }}
                >
                  <div className="relative mx-auto h-64 w-64 md:h-full md:w-full aspect-square">
                    <Image
                      src="https://placehold.co/400x400.png"
                      alt="Profile Picture"
                      fill
                      className="rounded-full object-cover shadow-lg md:rounded-lg"
                      data-ai-hint="professional headshot"
                    />
                  </div>
                </motion.div>
                <motion.div 
                  style={{ y: textY }}
                  className="px-6 pb-6 md:col-span-2 md:p-0"
                  transition={{ delay: 0.2 }}
                >
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    I am a driven Computer Science student with a profound passion for software engineering and web development. From a young age, I've been fascinated by how technology can solve real-world problems and connect people. This curiosity has led me to explore various programming languages and frameworks, always eager to learn and grow.
                  </p>
                  <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
                    My academic journey has provided me with a strong foundation in algorithms, data structures, and software design principles. I thrive in collaborative environments and enjoy the process of turning complex requirements into elegant, efficient, and scalable solutions. When I'm not coding, I enjoy contributing to open-source projects, reading tech blogs, and experimenting with new technologies.
                  </p>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </SectionWrapper>
  );
}
