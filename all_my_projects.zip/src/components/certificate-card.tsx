"use client"

import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ExternalLink } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card';

interface Certificate {
  title: string;
  organization: string;
  date: string;
  imageUrl: string;
  verifyUrl: string;
  imageHint: string;
}

interface CertificateCardProps {
  certificate: Certificate;
  index: number;
}

const cardVariants = {
  hidden: { opacity: 0, y: 50, scale: 0.9 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.1,
      duration: 0.5,
      type: 'spring',
      stiffness: 100,
    },
  }),
};

export function CertificateCard({ certificate, index }: CertificateCardProps) {
  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      custom={index}
      className="h-full"
      style={{ transformStyle: "preserve-3d" }}
      whileHover={{ y: -10, rotateX: 10, scale: 1.03, boxShadow: '0px 20px 30px -10px rgba(0,0,0,0.3)' }}
    >
      <Link href={certificate.verifyUrl} target="_blank" rel="noopener noreferrer">
        <Card className="group flex h-full transform flex-col overflow-hidden transition-all duration-300 hover:shadow-2xl">
          <CardHeader className="p-0">
            <div className="relative h-40 w-full overflow-hidden">
              <Image
                src={certificate.imageUrl}
                alt={certificate.title}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
                data-ai-hint={certificate.imageHint}
              />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors duration-300" />
            </div>
          </CardHeader>
          <CardContent className="flex-grow p-4">
            <CardTitle className="font-headline text-lg group-hover:text-primary transition-colors duration-300">
              {certificate.title}
            </CardTitle>
            <p className="mt-1 text-sm text-muted-foreground">{certificate.organization}</p>
          </CardContent>
          <CardFooter className="flex items-center justify-between p-4 pt-0">
            <p className="text-xs text-muted-foreground">{certificate.date}</p>
            <ExternalLink className="h-4 w-4 text-muted-foreground transition-transform duration-300 group-hover:text-primary group-hover:rotate-45" />
          </CardFooter>
        </Card>
      </Link>
    </motion.div>
  );
}
