import { SectionWrapper } from "./section-wrapper";
import { SectionHeader } from "./section-header";
import { CertificateCard } from "./certificate-card";

const certificatesData = [
  {
    title: "Next.js for Beginners",
    organization: "Vercel Academy",
    date: "March 2024",
    imageUrl: "https://placehold.co/600x400.png",
    verifyUrl: "#",
    imageHint: "tech certificate",
  },
  {
    title: "Advanced TypeScript",
    organization: "Codecademy",
    date: "January 2024",
    imageUrl: "https://placehold.co/600x400.png",
    verifyUrl: "#",
    imageHint: "coding diploma",
  },
  {
    title: "Responsive Web Design",
    organization: "freeCodeCamp",
    date: "November 2023",
    imageUrl: "https://placehold.co/600x400.png",
    verifyUrl: "#",
    imageHint: "design award",
  },
  {
    title: "Framer Motion Animations",
    organization: "Udemy",
    date: "September 2023",
    imageUrl: "https://placehold.co/600x400.png",
    verifyUrl: "#",
    imageHint: "animation course",
  },
];

export function Certificates() {
  return (
    <SectionWrapper id="certificates" className="bg-secondary" style={{ perspective: '2000px' }}>
      <SectionHeader 
        title="Certifications"
        description="A collection of my professional certifications and completed courses."
      />
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {certificatesData.map((cert, index) => (
          <CertificateCard key={index} certificate={cert} index={index} />
        ))}
      </div>
    </SectionWrapper>
  );
}
